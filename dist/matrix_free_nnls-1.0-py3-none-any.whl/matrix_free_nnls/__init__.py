"""
Created by Fabian on 06.11.2022.
"""

from .solve_nnls import solve_nnls